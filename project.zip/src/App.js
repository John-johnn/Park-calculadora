import React, { useState } from 'react';
import ParkingRateInput from './components/ParkingRateInput';
import TimeInput from './components/TimeInput';
import ResultDisplay from './components/ResultDisplay';
import ThemeToggle from './components/ThemeToggle';

const App = () => {
  const [rate, setRate] = useState(30);
  const [hours, setHours] = useState(0);
  const [minutes, setMinutes] = useState(0);
  const [darkMode, setDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const totalMinutes = (hours || 0) * 60 + (minutes || 0);
  const total = totalMinutes * rate;

  const styles = getStyles(darkMode);

  return (
    <div style={styles.container}>
      <ThemeToggle darkMode={darkMode} toggleDarkMode={toggleDarkMode} />
      <h1 style={styles.header}>ParkingPaws</h1>
      <p style={styles.subheader}>Calcula con estilo animal</p>
      
      <ParkingRateInput rate={rate} setRate={setRate} darkMode={darkMode} />
      <TimeInput 
        hours={hours} 
        setHours={setHours} 
        minutes={minutes} 
        setMinutes={setMinutes} 
        darkMode={darkMode}
      />
      <ResultDisplay total={total} darkMode={darkMode} />
    </div>
  );
};

const getStyles = (darkMode) => ({
  container: {
    maxWidth: 500,
    minHeight: '100vh',
    padding: 24,
    backgroundColor: darkMode ? '#212121' : '#FFF8E1',
    color: darkMode ? '#FFF' : '#000',
  },
  header: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    color: darkMode ? '#EFEBE9' : '#5D4037',
  },
  subheader: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 32,
    color: darkMode ? '#BCAAA4' : '#8D6E63',
  },
});

export default App;