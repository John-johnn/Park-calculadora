const ThemeToggle = ({ darkMode, toggleDarkMode }) => {
  return (
    <div style={styles.toggleContainer}>
      <button 
        onClick={toggleDarkMode}
        style={darkMode ? styles.darkButton : styles.lightButton}
      >
        {darkMode ? '🌙' : '☀️'}
      </button>
    </div>
  );
};

const styles = {
  toggleContainer: {
    position: 'absolute',
    top: 16,
    right: 16,
  },
  lightButton: {
    border: 'none',
    background: 'transparent',
    fontSize: 24,
    cursor: 'pointer',
    color: '#5D4037',
  },
  darkButton: {
    border: 'none',
    background: 'transparent',
    fontSize: 24,
    cursor: 'pointer',
    color: '#FFF',
  },
};

export default ThemeToggle;