const TimeInput = ({ hours, setHours, minutes, setMinutes, darkMode }) => {
  const styles = getStyles(darkMode);
  
  const handleHourChange = (e) => {
    const value = e.target.value;
    setHours(value === '' ? '' : Number(value));
  };

  const handleMinuteChange = (e) => {
    const value = e.target.value;
    setMinutes(value === '' ? '' : Number(value));
  };

  return (
    <div style={styles.container}>
      <div style={styles.timeInput}>
        <label style={styles.label}>Horas</label>
        <input
          type="number"
          value={hours}
          onChange={handleHourChange}
          style={styles.input}
          placeholder="0"
          min="0"
        />
      </div>
      <div style={styles.timeInput}>
        <label style={styles.label}>Minutos</label>
        <input
          type="number"
          value={minutes}
          onChange={handleMinuteChange}
          style={styles.input}
          placeholder="0"
          min="0"
          max="59"
        />
      </div>
    </div>
  );
};

const getStyles = (darkMode) => ({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  timeInput: {
    width: '48%',
  },
  label: {
    display: 'block',
    marginBottom: 8,
    fontSize: 16,
    color: darkMode ? '#EFEBE9' : '#5D4037',
  },
  input: {
    width: '100%',
    padding: 12,
    borderWidth: 1,
    borderColor: darkMode ? '#8D6E63' : '#A1887F',
    borderRadius: 8,
    backgroundColor: darkMode ? '#424242' : '#EFEBE9',
    fontSize: 16,
    color: darkMode ? '#FFF' : '#000',
  },
});

export default TimeInput;