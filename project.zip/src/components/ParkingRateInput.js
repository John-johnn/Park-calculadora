const ParkingRateInput = ({ rate, setRate, darkMode }) => {
  const styles = getStyles(darkMode);
  
  return (
    <div style={styles.inputContainer}>
      <label style={styles.label}>Precio por minuto (CLP)</label>
      <input
        type="number"
        value={rate}
        onChange={(e) => setRate(Number(e.target.value))}
        style={styles.input}
        placeholder="Ej: 30"
        min="0"
      />
    </div>
  );
};

const getStyles = (darkMode) => ({
  inputContainer: {
    marginBottom: 24,
  },
  label: {
    display: 'block',
    marginBottom: 8,
    fontSize: 16,
    color: darkMode ? '#EFEBE9' : '#5D4037',
  },
  input: {
    width: '100%',
    padding: 12,
    borderWidth: 1,
    borderColor: darkMode ? '#8D6E63' : '#A1887F',
    borderRadius: 8,
    backgroundColor: darkMode ? '#424242' : '#EFEBE9',
    fontSize: 16,
    color: darkMode ? '#FFF' : '#000',
  },
});

export default ParkingRateInput;