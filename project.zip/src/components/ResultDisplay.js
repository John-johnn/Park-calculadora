const ResultDisplay = ({ total, darkMode }) => {
  const styles = getStyles(darkMode);
  
  return (
    <div style={styles.container}>
      <h3 style={styles.title}>Total a pagar</h3>
      <p style={styles.amount}>
        {total.toLocaleString('es-CL', {
          style: 'currency',
          currency: 'CLP'
        })}
      </p>
    </div>
  );
};

const getStyles = (darkMode) => ({
  container: {
    marginTop: 24,
    padding: 16,
    backgroundColor: darkMode ? '#7CB342' : '#DCE775',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: darkMode ? '#558B2F' : '#AFB42B',
  },
  title: {
    fontSize: 18,
    marginBottom: 8,
    color: darkMode ? '#FFF' : '#5D4037',
  },
  amount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: darkMode ? '#E8F5E9' : '#33691E',
  },
});

export default ResultDisplay;